export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000' // ✅ URL สำหรับเชื่อมกับ Fastify API
};
