export const environment = {
  production: true,
  apiBaseUrl: 'http://localhost:3000' // 🔒 เปลี่ยนสำหรับ production
};
